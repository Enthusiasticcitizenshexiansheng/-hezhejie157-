

pA.0 -------------LED0
PA.1 -------------LED1
PA.2 -------------Usart2 tx
PA.3 -------------Usart2 rx

pA.5 -------------Beep




PA.9 ------------Usart1 TX
PA.10 ---------- Usart1 RX

PB10 -----------Usart3 Tx
PB11 -----------Usart3 RX

PC4--------------Exti 4
PC5--------------EXTI 5

PA6 --------------Timer3 CH1 PWM
PA7 --------------Timer3 CH2 PWM

PB.6 -------------Timer4 CH1(in capture���벶��)


PB.10 -------------I2C2 SCL
PB.11 -------------I2C2 SDA
 
PE9 --------------  Timer1 CH1
PE8 --------------  Timer1 CH1N
PE10 -------------- Timer1 CH2
PE11 -------------- Timer1 CH2N




PC0--------------ADC1 ͨ��10
PC1--------------ADC1 ͨ��11
PC2--------------ADC1 ͨ��12
PC3--------------ADC1 ͨ��13




