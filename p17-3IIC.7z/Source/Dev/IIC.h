#ifndef __I2C_H__
#define __I2C_H__


#include "config.h"
#include "stm32f10x.h"



#define I2C_SCL_GPIO_PORT  GPIOB
#define I2C_SCL_GPIO_PIN  GPIO_Pin_10
#define I2C_SDA_GPIO_PORT  GPIOB
#define I2C_SDA_GPIO_PIN  GPIO_Pin_11



//�ߵ͵�ƽ
#define I2C_SCL_LOW        GPIO_ResetBits(I2C_SCL_GPIO_PORT,I2C_SCL_GPIO_PIN)
#define I2C_SCL_HIGH       GPIO_SetBits(I2C_SCL_GPIO_PORT,I2C_SCL_GPIO_PIN)

#define I2C_SDA_LOW        GPIO_ResetBits(I2C_SDA_GPIO_PORT,I2C_SDA_GPIO_PIN)
#define I2C_SDA_HIGH       GPIO_SetBits(I2C_SDA_GPIO_PORT,I2C_SDA_GPIO_PIN)

//������Ҫ���������
#define  I2C_SDA_READ  GPIO_ReadInputDataBit(I2C_SDA_GPIO_PORT,I2C_SDA_GPIO_PIN)

#define   I2C_ACK    0
#define   I2C_NOACK  1




void I2cGpioInit(void);
void I2cStart(void);
void I2cStop(void);
//Ӧ�� �� ��Ӧ��
void I2cAck(void);
void I2cNoAck(void);
//��Ӧ��
unsigned char I2cReadAck(void);  

//��д����
void I2cWriteByte(unsigned char ByteData);
void I2cReadByte(unsigned char *ByteData);

#endif


