#ifndef __AT24C02_H__
#define __AT24C02_H__


#include "config.h"
#include "stm32f10x.h"
#include "IIC.h"

#define AT24C02_EN 1

#if AT24C02_EN == 1

#define EEPROM_DEV_ADDR  0xA0
#define EEPROM_WR    0X00
#define EEPROM_RD    0X00


void AT24c02Init(void);
void At24c02Write(unsigned char addr,unsigned char* buff,int size);
void At24c02Read(unsigned char addr,unsigned char* buff,int size);


#endif
#endif

