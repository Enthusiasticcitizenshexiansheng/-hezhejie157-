#include "AT24C02.h"



#if AT24C02_EN == 1
void AT24c02Init(void)
{
 I2cGpioInit();
}



   //һ����ĸдһ���ֽ�
static void At24c02WriteByte(unsigned char addr,unsigned char ByteData)
{
    I2cStart();
    I2cWriteByte(EEPROM_DEV_ADDR|EEPROM_WR);
   
		
		//Ӧ��
		I2cReadAck();  
		
	   //���ݵ�ַ
   I2cWriteByte(addr);
   I2cReadAck();  

	 I2cWriteByte(ByteData);
   I2cReadAck();  

	
	 I2cStop();
}

void At24c02Write(unsigned char addr,unsigned char* buff,int size)
{
    int  cnt;
   for(cnt=0;cnt<size;cnt++)
At24c02WriteByte( addr + cnt,*(buff + cnt));
	
}





void At24c02Read(unsigned char addr,unsigned char* buff,int size)
{
    I2cStart();
   
   	I2cWriteByte(EEPROM_DEV_ADDR|EEPROM_WR);
		//Ӧ��
		I2cReadAck();  
		
	  //���ݵ�ַ
   I2cWriteByte(addr);
   I2cReadAck();  
	
	
	
	//���� ���ж�����
  I2cStart();
	
  I2cWriteByte(EEPROM_DEV_ADDR|EEPROM_RD);
	I2cReadAck(); 
	 
	
  while(size--)
	{
	 I2cReadByte(buff++);
		
		
		if(size)
			I2cAck();
		else
			I2cNoAck();
		
	}
	
	 I2cStop();

}

#endif


