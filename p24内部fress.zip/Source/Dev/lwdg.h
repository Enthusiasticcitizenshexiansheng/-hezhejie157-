#ifndef __IWDG_H__
#define __IWDG_H__

#include "config.h"
#include "stm32f10x.h"

//���Ź���ʼ��
void IwdgInit(unsigned char psc,unsigned short arr);

void IwdgFeed();


#endif

