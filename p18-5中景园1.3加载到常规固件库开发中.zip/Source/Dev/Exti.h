
#ifndef __EXTI_H__
#define __EXTI_H__


#include "config.h"
#include "stm32f10x.h"


void ExtiGpioInit(void);
void ExtiNvicInit(void);
void ExtiModeInit(void);
void ExtiInit(void);


#endif


